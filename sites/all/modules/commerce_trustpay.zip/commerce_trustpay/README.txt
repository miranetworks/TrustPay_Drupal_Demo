The Commerce TrustPay module allows you to configure your site to process payments 
through TrustPay Gateway API.